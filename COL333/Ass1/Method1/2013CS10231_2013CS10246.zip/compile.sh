#!/bin/bash

g++ Schedule.cpp -O3
