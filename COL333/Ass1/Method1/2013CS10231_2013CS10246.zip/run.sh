#!/bin/bash

./a.out $1 > $2