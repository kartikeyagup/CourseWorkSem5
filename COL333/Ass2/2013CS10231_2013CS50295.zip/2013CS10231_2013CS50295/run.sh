#!/bin/bash
./a.out