#!/bin/bash
g++ Game.cpp PalindromePopulation.cpp GameTree.cpp GameClient.cpp -std=gnu++11 -O3
